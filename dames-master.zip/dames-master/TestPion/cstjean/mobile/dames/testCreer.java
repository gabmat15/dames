package cstjean.mobile.dames;

public class testCreer {
    
    public void testCreer(){
        //assertEquals("Blanc");
        //assertEquals("Noir");
    }
    
}
