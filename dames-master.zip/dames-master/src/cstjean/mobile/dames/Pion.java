package cstjean.mobile.dames;

public class Pion {

    private final String couleur;

    Pion(String couleur){
        this.couleur = couleur;
    }

    String getCouleur() {
        return couleur;
    }
}
