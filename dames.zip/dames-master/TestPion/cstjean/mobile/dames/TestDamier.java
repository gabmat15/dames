package cstjean.mobile.dames;

import junit.framework.TestCase;

import java.util.LinkedList;
import java.util.List;

public class TestDamier extends TestCase{
    private List<Pion> damier = new LinkedList<>();
    public  void  testCreer() {
        damier.ajouterPion(38, pion1);
    /**blabla**/
    }
}
