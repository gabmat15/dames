package cstjean.mobile.dames;

import junit.framework.TestCase;

public class TestPion extends TestCase {

    public void testCreer(){
        Pion pion1 = new Pion("Blanc");
        assertEquals("Blanc", pion1.getCouleur());
        Pion pion2 = new Pion("Noir");
        assertEquals("Noir", pion2.getCouleur());
    }
}
