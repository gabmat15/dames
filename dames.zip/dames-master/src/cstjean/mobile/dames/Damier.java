package cstjean.mobile.dames;

import java.util.LinkedList;
import java.util.List;

public class Damier {
    private final List<Pion> pions = new LinkedList<>();
    /**
     * la position du pion.
     */
    private final int position;


    void ajouterPion(int position,Pion pion)
    {
        pions.add(position, pion);
    }
    Pion getPion(int index) {
        return pions.get(index);
    }

}
