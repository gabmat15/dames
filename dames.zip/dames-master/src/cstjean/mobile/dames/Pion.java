package cstjean.mobile.dames;

/**
 * classe permetant de géger un pion.
 *
 * @author Gabriel Mathias et Sabrina Antinozzi
 */
public class Pion {
    /**
     * La couleur du pion.
     */
    private final String couleur;

    /**
     * Constructeur du pion.
     *
     * @param couleur
     * @param position
     */
    Pion(String couleur) {
        this.couleur = couleur;

    }

    /**
     * Pour obtenir la couleur du pion.
     *
     * @return couleur
     */
    String getCouleur() {
        return couleur;
    }


}
